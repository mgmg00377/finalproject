// Reference to the task input field
var taskInput = document.getElementById("taskInput");

// Reference to the task table body
var taskTableBody = document.getElementById("taskTableBody");

// Load tasks from localStorage when the page loads
function loadTasks() {
  var tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  taskTableBody.innerHTML = ""; // Clear previous tasks

  for (var i = 0; i < tasks.length; i++) {
    addTaskToTable(tasks[i].id, tasks[i].text);
  }
}

// Save tasks to localStorage
function saveTasks(tasks) {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Add a new task
function addTask() {
  var text = taskInput.value.trim();
  if (text === "") return;

  var tasks = JSON.parse(localStorage.getItem("tasks")) || [];

  var newTask = {
    id: new Date().getTime(), // Unique ID using timestamp
    text: text
  };

  tasks.push(newTask);
  saveTasks(tasks);

  addTaskToTable(newTask.id, newTask.text);

  // Clear the input field and focus again
  taskInput.value = "";
  taskInput.focus();
}

// Display task in the table
function addTaskToTable(id, text) {
  var row = taskTableBody.insertRow();
  var taskCell = row.insertCell(0);
  var actionCell = row.insertCell(1);

  taskCell.textContent = text;

  // Create Edit and Delete buttons
  actionCell.innerHTML =
    '<button onclick="editTask(' + id + ', this)">Edit</button>' +
    ' <button onclick="deleteTask(' + id + ', this)">Delete</button>';
}

// Edit a task
function editTask(id, button) {
  var cell = button.parentElement.previousElementSibling;
  var oldText = cell.textContent;

  // Replace text with an input field
  cell.innerHTML = '<input type="text" value="' + oldText + '" onblur="saveEdit(' + id + ', this)">';
  cell.querySelector("input").focus();
}

// Save the edited task
function saveEdit(id, input) {
  var newText = input.value.trim();
  if (newText === "") {
    newText = "Unnamed task";
  }

  var tasks = JSON.parse(localStorage.getItem("tasks")) || [];

  for (var i = 0; i < tasks.length; i++) {
    if (tasks[i].id === id) {
      tasks[i].text = newText;
      break;
    }
  }

  saveTasks(tasks);
  input.parentElement.textContent = newText;
}

// Delete a task
function deleteTask(id, button) {
  var confirmDelete = confirm("Delete this task?");
  if (confirmDelete) {
    var tasks = JSON.parse(localStorage.getItem("tasks")) || [];

    // Filter out the task to be deleted
    var updatedTasks = tasks.filter(function(task) {
      return task.id !== id;
    });

    saveTasks(updatedTasks);

    // Remove the task from the table
    button.closest("tr").remove();
  }
}

// Load tasks when the page loads
window.onload = loadTasks;

// Allow adding task by pressing "Enter"
taskInput.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    addTask();
  }
});
